name = "NCBI_Companion"

"""
The main Entrez web page is available at:
http://www.ncbi.nlm.nih.gov/Entrez/
Entrez Programming Utilities web page is available at:
http://www.ncbi.nlm.nih.gov/books/NBK25501/


function used:

esearch
efetch
elink

"""

