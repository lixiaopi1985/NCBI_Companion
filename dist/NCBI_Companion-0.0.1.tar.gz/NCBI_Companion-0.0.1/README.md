# NCBI_Companion

# NCBI_Companion
NCBI_Companion targets to construct database from Genbank implementing its API.

## Contents

**1. class LoadSpecies**

>This class is to used fetch species name contains in csv file, text file, excel or fasta file.

**Functions**

ReadSpeciesFile_excel(sp_col='act_sym_fullname', sheetname = 0, header = 0,  fullname = False)

ReadSpeciesFile_csv(sp_col='act_sym_fullname', sheetname = 0, header = 0, fullname = False)

ExtractSpeciesFromFasta(ranges, delimiter = ' ')

>all those functions return a list of species names

**Usage**

species = LoadSpecies(input_file, output_file, ifout = True)
species.ReadSpeciesFile_excel(sp_col='act_sym_fullname', sheetname = 0, header = 0,  fullname = False)



**2. class NCBI_Companion**
> This class implements Biopython Entrez to interact with NCBI/Genbank API to get either get accession id, taxonomy id, sequences or taxonomy ranking, or converting them

**Functions**

ncbi_Search2Acc

ncbi_Species2Acc

ncbi_GetSeqsFromAcc

GetIdFromFasta

ncbi_GetTaxIdFromIDs

ncbi_Species2Taxa


#Instruction

Examples:

1. For known species list (a csv file)

First, extract species names.(it can get Uid, Accession, or Species Names from your file and return a list)

    • LoadSpecies_object = NCBI_Companion.LoadSpecies(‘your_file.csv”, ‘output_text_containing_ID_or_Species’)
    • species_list = LoadSpecies_object.ReadSpeciesFile_csv(‘Column_contain_you_want_to_get’)
      

Second, create a companion object (name is arbituray).

    • Companion = NCBI_Companion.NCBI_Tools(api_key, email, ‘database_name’, ‘which_ncbi_database(default ‘nuccore’)’, ‘what_ID (default ‘acc’)’)

Since we have a list of species, we need to get accession ID to access taxonomy ranking

workflow (P2-P3-P4-P7) (Here P represents each function you need to use for this workflow)

    • companion.ncbi_Species2Acc(species_list, ‘other_term you want to search (such as “trnL”’)
    • companion.ncbi_GetSeqsFromAcc(‘Sp2AccIDs’, ‘acc_id’(default)) --- *here Sp2AccIDs is the table created in the database from the first calling of the function
    • companion.ncbi_GetTaxIdFromIDs(‘Sp2AccIDs’, ‘acc_id’(default))
    • companion.ncbi_Species2Taxa(species_list)


Third part is to use Sqilte_Dumps class to get a fasta and mapping file.

    • Tracker = companion.getTracker()
    • Dump = NCBI_Companion.Sqlite_Dumps(‘database’, ‘output-prefix’, Tracker)
    • dump.sqlite_dump()
